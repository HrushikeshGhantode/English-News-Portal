﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Configuration;
public partial class Contact : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        generate_ID();
    }
    private void generate_ID()
    {
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        con = new SqlConnection(ConfigurationManager.AppSettings["LIS"]);
        // con = new SqlConnection(ConfigurationManager.AppSettings["LIS_local"]);
        cmd = new SqlCommand();
        con.Open();
        cmd.Connection = con;
        cmd.CommandText = "select id from  ContactUs order by id desc";
        cmd.Connection = con;
        object obj = cmd.ExecuteScalar();
        if (obj == null)
        {
            hfId.Value = "1";
        }
        else
        {
            int n = Convert.ToInt32(obj);
            n = n + 1;
            hfId.Value = n.ToString();
        }
        con.Close();
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.AppSettings["LIS"]);        
        con.Open();

        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "insert into ContactUs(id,uname,mobile,address,msg)values(@id,@uname,@mobile,@address,@msg)";

        cmd.Parameters.AddWithValue("@id", hfId.Value);
        cmd.Parameters.AddWithValue("@uname", txtName.Text);
        cmd.Parameters.AddWithValue("@mobile", txtMobile.Text);
        cmd.Parameters.AddWithValue("@address", txtAddress.Text);
        cmd.Parameters.AddWithValue("@msg", txtMsg.Text);
        
        cmd.Connection = con;

        int n = cmd.ExecuteNonQuery();
        con.Close();

        if (n > 0)
        {           
            lblmsg.Text = "Message Submitted Successfully !";
            txtAddress.Text = "";
            txtMobile.Text = "";
            txtMsg.Text = "";
            txtName.Text = "";

        }
        else
        {
            Response.Write("Error!");
        }
    }
}