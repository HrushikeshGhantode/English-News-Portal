﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_AdvertisementSlider : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        img_1.ImageUrl = "~/advertisement/1.PNG";
        img_2.ImageUrl = "~/advertisement/2.PNG";
        img_3.ImageUrl = "~/advertisement/3.PNG";
        img_4.ImageUrl = "~/advertisement/4.PNG";
        //img_5.ImageUrl = "~/images/image-slider-5.JPG";

    }


    protected void btn_slider1_Click(object sender, EventArgs e)
    {
        String ppath = "";
        String ipath = "";
        ppath = Server.MapPath("~/advertisement");


        ipath = ppath + "\\1.PNG";

        FileUpload1.SaveAs(ipath);


    }
    protected void btn_slider2_Click(object sender, EventArgs e)
    {
        String ppath = "";
        String ipath = "";
        ppath = Server.MapPath("~/advertisement");


        ipath = ppath + "\\2.PNG";

        FileUpload2.SaveAs(ipath);

    }
    protected void btn_slider3_Click(object sender, EventArgs e)
    {
        String ppath = "";
        String ipath = "";
        ppath = Server.MapPath("~/advertisement");


        ipath = ppath + "\\3.PNG";

        FileUpload3.SaveAs(ipath);

    }
    protected void btn_slider4_Click(object sender, EventArgs e)
    {
        String ppath = "";
        String ipath = "";
        ppath = Server.MapPath("~/advertisement");


        ipath = ppath + "\\4.PNG";

        FileUpload4.SaveAs(ipath);

    }
   
}