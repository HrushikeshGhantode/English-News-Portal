﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_Advertisment : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        img_1.ImageUrl = "~/Advertisement/1.jpg";
        img_2.ImageUrl = "~/Advertisement/2.gif";
        img_3.ImageUrl = "~/Advertisement/3.jpg";
        img_4.ImageUrl = "~/Advertisement/4.jpg";
        img_5.ImageUrl = "~/Advertisement/5.jpg";

    }


    protected void btn_slider1_Click(object sender, EventArgs e)
    {
        String ppath = "";
        String ipath = "";
        ppath = Server.MapPath("~/Advertisement");


        ipath = ppath + "\\1.jpg";

        FileUpload1.SaveAs(ipath);


    }
    protected void btn_slider2_Click(object sender, EventArgs e)
    {
        String ppath = "";
        String ipath = "";
        ppath = Server.MapPath("~/Advertisement");


        ipath = ppath + "\\2.jpg";

        FileUpload2.SaveAs(ipath);

    }
    protected void btn_slider3_Click(object sender, EventArgs e)
    {
        String ppath = "";
        String ipath = "";
        ppath = Server.MapPath("~/Advertisement");


        ipath = ppath + "\\3.jpg";

        FileUpload3.SaveAs(ipath);

    }
    protected void btn_slider4_Click(object sender, EventArgs e)
    {
        String ppath = "";
        String ipath = "";
        ppath = Server.MapPath("~/Advertisement");


        ipath = ppath + "\\4.jpg";

        FileUpload4.SaveAs(ipath);

    }
    protected void btn_slider5_Click(object sender, EventArgs e)
    {
        String ppath = "";
        String ipath = "";
        ppath = Server.MapPath("~/Advertisement");


        ipath = ppath + "\\5.jpg";

        FileUpload5.SaveAs(ipath);

    }
}