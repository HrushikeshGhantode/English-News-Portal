﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_NewBreaking : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        hfDate.Value = DateTime.Now.ToShortDateString();
        int n=SqlDataSaveData.Insert();
        if (n > 0)
        {
            lblmsg.Text = "News Saved Successfully !";
        }
        else
        {
            lblmsg.Text = "Error !";
        }

    }
}