﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;

public partial class admin_NewReporter : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        generate_ID();
    }
    private void generate_ID()
    {
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        con = new SqlConnection(ConfigurationManager.AppSettings["LIS"]);
        //con = new SqlConnection(ConfigurationManager.AppSettings["LIS_local"]);
        cmd = new SqlCommand();
        con.Open();
        cmd.Connection = con;
        cmd.CommandText = "select id from  Reporter order by id desc";
        cmd.Connection = con;
        object obj = cmd.ExecuteScalar();
        if (obj == null)
        {
            hfId.Value = "1";
        }
        else
        {
            int n = Convert.ToInt32(obj);
            n = n + 1;
            hfId.Value = n.ToString();
        }
        con.Close();
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        string fname = "no_photo.jpg";
        String ppath="";
        if (fileuploadImage.HasFile)
        {

            string str = fileuploadImage.FileName;
            int pos = str.LastIndexOf(".");
            string ext = str.Substring(pos + 1);
                fname = "R_" + hfId.Value.ToString() + "." + ext;
            string upath = Server.MapPath("../Reporter_Photos");
            ppath = upath + "\\" + fname;

        }

            SqlConnection con = new SqlConnection(ConfigurationManager.AppSettings["LIS"]);
            // SqlConnection con = new SqlConnection(ConfigurationManager.AppSettings["LIS_local"]);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "insert into Reporter(id,name,address,city,mobile,email,photo)values(@id,@name,@address,@city,@mobile,@email,@photo)";

            cmd.Parameters.AddWithValue("@id", hfId.Value);
            cmd.Parameters.AddWithValue("@name",txtName.Text);
            cmd.Parameters.AddWithValue("@address",txtAddress.Text);
            cmd.Parameters.AddWithValue("@city",ddlDistrict.SelectedItem.ToString());
            cmd.Parameters.AddWithValue("@mobile", txtMobile.Text);
            cmd.Parameters.AddWithValue("@email",txtEmail.Text);
            cmd.Parameters.AddWithValue("@photo", fname);            
            
            cmd.Connection = con;

            int n = cmd.ExecuteNonQuery();
            if (n > 0)
            {
                fileuploadImage.SaveAs(ppath);
                lblmsg.Text = "Reporter Register Successfully !";
                txtAddress.Text = "";
                ddlDistrict.SelectedIndex = 1;
                txtEmail.Text = "";
                txtMobile.Text = "";
                txtName.Text = "";
            }
            else
            {
                Response.Write("Error!");
            }            
            con.Close();
        

    }

}