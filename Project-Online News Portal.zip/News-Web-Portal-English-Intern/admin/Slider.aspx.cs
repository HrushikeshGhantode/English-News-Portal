﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_Slider : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        img_1.ImageUrl ="~/images/image-slider-1.JPG";
        img_2.ImageUrl = "~/images/image-slider-2.JPG";
        img_3.ImageUrl = "~/images/image-slider-3.JPG";
        img_4.ImageUrl = "~/images/image-slider-4.JPG";
        img_5.ImageUrl = "~/images/image-slider-5.JPG";

    }


    protected void btn_slider1_Click(object sender, EventArgs e)
    {
        String ppath = "";
        String ipath = "";
        ppath = Server.MapPath("~/images");

       
        ipath = ppath + "\\image-slider-1.JPG";

        FileUpload1.SaveAs(ipath);

        
    }
    protected void btn_slider2_Click(object sender, EventArgs e)
    {
        String ppath = "";
        String ipath = "";
        ppath = Server.MapPath("~/images");


        ipath = ppath + "\\image-slider-2.JPG";

        FileUpload2.SaveAs(ipath);

    }
    protected void btn_slider3_Click(object sender, EventArgs e)
    {
        String ppath = "";
        String ipath = "";
        ppath = Server.MapPath("~/images");


        ipath = ppath + "\\image-slider-3.JPG";

        FileUpload3.SaveAs(ipath);

    }
    protected void btn_slider4_Click(object sender, EventArgs e)
    {
        String ppath = "";
        String ipath = "";
        ppath = Server.MapPath("~/images");


        ipath = ppath + "\\image-slider-4.JPG";

        FileUpload4.SaveAs(ipath);

    }
    protected void btn_slider5_Click(object sender, EventArgs e)
    {
        String ppath = "";
        String ipath = "";
        ppath = Server.MapPath("~/images");


        ipath = ppath + "\\image-slider-5.JPG";

        FileUpload5.SaveAs(ipath);

    }
}