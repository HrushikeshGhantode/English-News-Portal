﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Globalization;

public partial class admin_UpdateNews : System.Web.UI.Page
{
    string fname;
    protected void Page_Load(object sender, EventArgs e)
    {
        hfId.Value = Request.QueryString["id"].ToString();

        if (this.IsPostBack == false)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.AppSettings["LIS"]);
            SqlCommand cmd = new SqlCommand();

            con.Open();

            cmd.CommandText = "Select cata,dist,title,details,photo,regdate,time1,reportername from Data where id=@id";
            cmd.Parameters.AddWithValue("@id", Request.QueryString["id"].ToString());

            cmd.Connection = con;

            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                ddlCata.Text = dr.GetString(dr.GetOrdinal("cata"));

                ddlDistrict.Text = dr.GetString(dr.GetOrdinal("dist"));

                txtTitle.Text = dr.GetString(dr.GetOrdinal("title"));
                txtDesc.Text = dr.GetString(dr.GetOrdinal("details"));
                
               // fname=dr.GetString(dr.GetOrdinal("photo"));

                Response.Write(fname);

                Image2.ImageUrl = "../News_Photos/" + dr.GetString(dr.GetOrdinal("photo"));

                DateTime dt = dr.GetDateTime(dr.GetOrdinal("regdate"));

                //txtDate.Text = dt.ToShortDateString();
                txtDate.Text = dt.ToString("dd/MM/yyyy");

                txttime.Text = dr.GetString(dr.GetOrdinal("time1"));

                txtreporter.Text = dr.GetString(dr.GetOrdinal("reportername"));
            }

            con.Close();

            getVideoCode(Request.QueryString["id"].ToString());
        }
    }

    protected void getVideoCode(string id)
    {
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        con = new SqlConnection(ConfigurationManager.AppSettings["LIS"]);
        // con = new SqlConnection(ConfigurationManager.AppSettings["LIS_local"]);
        cmd = new SqlCommand();
        con.Open();
        cmd.Connection = con;
        cmd.CommandText = "select url from Video where news_id=@id";
        cmd.Parameters.AddWithValue("@id", id);
        cmd.Connection = con;
        object obj = cmd.ExecuteScalar();
        if (obj == null)
        {
            
        }
        else
        {
            txtUrl.Text = obj.ToString();
        }
        con.Close();
    }

    protected void updateVideoCode()
    {
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        con = new SqlConnection(ConfigurationManager.AppSettings["LIS"]);
        // con = new SqlConnection(ConfigurationManager.AppSettings["LIS_local"]);
        cmd = new SqlCommand();
        con.Open();
        cmd.Connection = con;
        cmd.CommandText = "select video from Data where id=@id";
        cmd.Parameters.AddWithValue("@id", hfId.Value);
        cmd.Connection = con;        
        object obj = cmd.ExecuteScalar();
        con.Close();

        if (obj.ToString() == "Yes")
        {
            updateOldVideo();  // fun. will update only video if exist
        }
        else
        {
            updateDataVideo(); // fun. will update news and insert video if not exist.
        }
        
    }

    protected void updateOldVideo()
    {
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        con = new SqlConnection(ConfigurationManager.AppSettings["LIS"]);
        // con = new SqlConnection(ConfigurationManager.AppSettings["LIS_local"]);
        cmd = new SqlCommand();
        con.Open();
        cmd.Connection = con;
        cmd.CommandText = "update Video set url=@url where news_id=@id";
        cmd.Parameters.AddWithValue("@url", txtUrl.Text);
        cmd.Parameters.AddWithValue("@id", hfId.Value);

        cmd.Connection = con;
        cmd.ExecuteNonQuery();
        con.Close();    
    }
    
    protected void updateDataVideo()
    {
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        con = new SqlConnection(ConfigurationManager.AppSettings["LIS"]);
        // con = new SqlConnection(ConfigurationManager.AppSettings["LIS_local"]);
        cmd = new SqlCommand();
        con.Open();
        cmd.Connection = con;
        cmd.CommandText = "update Data set Video='Yes' where id=@id";        
        cmd.Parameters.AddWithValue("@id", hfId.Value);

        cmd.Connection = con;
        cmd.ExecuteNonQuery();
        con.Close();

        SqlConnection con1 = new SqlConnection();
        SqlCommand cmd1 = new SqlCommand();
        con1 = new SqlConnection(ConfigurationManager.AppSettings["LIS"]);
        // con = new SqlConnection(ConfigurationManager.AppSettings["LIS_local"]);
        cmd1 = new SqlCommand();
        con1.Open();
        cmd1.Connection = con1;
        cmd1.CommandText = "insert into Video(id,news_id,title,url)values(@id,@news_id,@title,@url)";
        BasicCode b = new BasicCode();
        cmd1.Parameters.AddWithValue("@id",b.generateID("id", "Video"));
        cmd1.Parameters.AddWithValue("@news_id",Convert.ToInt32(hfId.Value));
        cmd1.Parameters.AddWithValue("@title", txtTitle.Text);
        cmd1.Parameters.AddWithValue("@url", txtUrl.Text);

        cmd1.Connection = con1;

        int n = cmd1.ExecuteNonQuery();
        con1.Close();
    }


    protected void btnSubmit_Click(object sender, EventArgs e)
    {                
        DateTime dt = DateTime.ParseExact(txtDate.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture);

        SqlConnection con = new SqlConnection(ConfigurationManager.AppSettings["LIS"]);
        
        con.Open();

        SqlCommand cmd = new SqlCommand();

        if (fileuploadImage.HasFile)
        {
            //-----------------------code to create File Name and Save it.-------------
            string str = fileuploadImage.FileName;
            int pos = str.LastIndexOf(".");
            string ext = str.Substring(pos + 1);
            fname = "p_" + hfId.Value.ToString() + "." + ext;

            string upath = Server.MapPath("../News_Photos");

            String ppath = upath + "\\" + fname;

            fileuploadImage.SaveAs(ppath);

            cmd.CommandText = "Update Data set cata=@cata,title=@t,details=@d,photo=@p,regdate=@r,time1=@time1,reportername=@reportername,dist=@dist where id=@i";
            cmd.Parameters.AddWithValue("@p", fname);
        }
        else
        {
            cmd.CommandText = "Update Data set cata=@cata,title=@t,details=@d,regdate=@r,time1=@time1,reportername=@reportername,dist=@dist where id=@i";
        }


        cmd.Parameters.AddWithValue("@i",Request.QueryString["id"].ToString());

        cmd.Parameters.AddWithValue("@cata", ddlCata.SelectedItem.ToString());
        cmd.Parameters.AddWithValue("@t", txtTitle.Text);
        cmd.Parameters.AddWithValue("@d", txtDesc.Text);
                
        cmd.Parameters.AddWithValue("@r", dt);
        cmd.Parameters.AddWithValue("@time1", txttime.Text);
        cmd.Parameters.AddWithValue("@reportername", txtreporter.Text);
        cmd.Parameters.AddWithValue("@dist", ddlDistrict.SelectedItem.ToString());

        cmd.Connection = con;

        int n = cmd.ExecuteNonQuery();
        if (n > 0)
        {
            lblmsg.Text = "News Changed Successfully !";
              
        }
        else
        {
            Response.Write("Error!");
        }

        con.Close();

        if (txtUrl.Text == "")
        {
        }
        else
        {
            updateVideoCode();
        }
        txtDesc.Text = "";
        txtTitle.Text = "";
        txtDate.Text = "";
        txttime.Text = "";
        txtreporter.Text = "";
        txtUrl.Text = "";
    }
}