﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;
public partial class admin_New_Events : System.Web.UI.Page
{
    
    protected void Page_Load(object sender, EventArgs e)
    {
        generate_ID();
    }
    private void generate_ID()
    {
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        con = new SqlConnection(ConfigurationManager.AppSettings["LIS"]);
       // con = new SqlConnection(ConfigurationManager.AppSettings["LIS_local"]);
        cmd = new SqlCommand();
        con.Open();
        cmd.Connection = con;
        cmd.CommandText = "select id from  Data order by id desc";
        cmd.Connection = con;
        object obj = cmd.ExecuteScalar();
        if (obj == null)
        {
            hfId.Value = "1";
        }
        else
        {
            int n = Convert.ToInt32(obj);
            n = n + 1;
            hfId.Value = n.ToString();
        }
        con.Close();
    }


    protected void btnSubmit_Click(object sender, EventArgs e)
    {

        string fname="no_photo.jpg";
        
        System.DateTime myDate;
        
        //-----------------------------------------------------
        DateTime dt = DateTime.ParseExact(txtDate.Text, "dd/MM/yyyy",CultureInfo.InvariantCulture);
       
        string d = dt.ToString("dd/MM/yyyy");
        
        if (fileuploadImage.HasFile)
        {
            //-----------------------code to create File Name and Save it.-------------
            string str = fileuploadImage.FileName;
            int pos = str.LastIndexOf(".");
            string ext = str.Substring(pos + 1);
            fname = "p_" + hfId.Value.ToString() + "." + ext;

            string upath = Server.MapPath("../News_Photos");

            String ppath = upath + "\\" + fname;
            
            fileuploadImage.SaveAs(ppath);
        }// end of Main If


            hfDate.Value = txtDate.Text;

            SqlConnection con = new SqlConnection(ConfigurationManager.AppSettings["LIS"]);
            // SqlConnection con = new SqlConnection(ConfigurationManager.AppSettings["LIS_local"]);

            con.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "insert into Data(id,cata,title,details,photo,regdate,time1,reportername,dist,video,taluka,village)values(@i,@cata,@t,@d,@p,@r,@time1,@reportername,@dist,@video,@taluka,@village)";

            cmd.Parameters.AddWithValue("@i", hfId.Value);
            cmd.Parameters.AddWithValue("@cata", ddlCata.SelectedItem.ToString());
            cmd.Parameters.AddWithValue("@t", txtTitle.Text);
            cmd.Parameters.AddWithValue("@d", txtDesc.Text);
            cmd.Parameters.AddWithValue("@p", fname);
            //cmd.Parameters.AddWithValue("@r", myDate.ToString());
            cmd.Parameters.AddWithValue("@r", dt);
            cmd.Parameters.AddWithValue("@time1",txttime.Text);
            cmd.Parameters.AddWithValue("@reportername", txtreporter.Text);
            cmd.Parameters.AddWithValue("@dist",ddlDistrict.SelectedItem.ToString());
            cmd.Parameters.AddWithValue("@taluka",txtTaluka.Text);
            cmd.Parameters.AddWithValue("@village", txtVillage.Text);

            if (txtUrl.Text == "")
            {
                cmd.Parameters.AddWithValue("@video", "No");
            }
            else
            {
                cmd.Parameters.AddWithValue("@video", "Yes");
            }

            cmd.Connection = con;

            int n = cmd.ExecuteNonQuery();
            con.Close();

            if (n > 0)
            {

                if (txtUrl.Text != "")
                {
                    saveVideo(hfId.Value);
                }
                lblmsg.Text = "News Uploaded Successfully !";
                txtDesc.Text = "";
                txtTitle.Text = "";
                txtDate.Text = "";
                txttime.Text = "";
            }
            else
            {
                Response.Write("Error!");
            }
        
    }

    private void saveVideo(string newsid)
    {
        BasicCode b = new BasicCode();

        SqlConnection con = new SqlConnection(ConfigurationManager.AppSettings["LIS"]);
        con.Open();

        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "insert into Video(id,news_id,title,url)values(@id,@news_id,@title,@url)";

        cmd.Parameters.AddWithValue("@id",b.generateID("id", "Video"));
        cmd.Parameters.AddWithValue("@news_id",Convert.ToInt32(newsid));
        cmd.Parameters.AddWithValue("@title", txtTitle.Text);
        cmd.Parameters.AddWithValue("@url", txtUrl.Text);

        cmd.Connection = con;

        int n = cmd.ExecuteNonQuery();
        if (n > 0)
        {
            //lblmsg.Text = "Video Uploaded Successfully !";
            //txtTitle.Text = "";
            //txtUrl.Text = "";
        }
        else
        {
            Response.Write("Error!");
        }

        con.Close();
    }
}