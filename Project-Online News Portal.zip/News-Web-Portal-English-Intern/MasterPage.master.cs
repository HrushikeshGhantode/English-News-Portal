﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {


        saveVisitorCount();
        showVisitorCount();


    }

    void saveVisitorCount()
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.AppSettings["LIS"]);
        SqlCommand cmd = new SqlCommand();
        con.Open();

        cmd.CommandText = "update Visitors set count=count+1";
        cmd.Connection = con;
        int n = cmd.ExecuteNonQuery();
        con.Close();
    }

    void showVisitorCount()
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.AppSettings["LIS"]);
        SqlCommand cmd = new SqlCommand();
        con.Open();

        cmd.Connection = con;
        cmd.CommandText = "select count from Visitors";
        cmd.Connection = con;

        object obj = cmd.ExecuteScalar();
        if (obj == null)
        {
            lblcounter.Text = "1";
        }
        else
        {
            lblcounter.Text = obj.ToString();
        }
        con.Close();
    }
}
