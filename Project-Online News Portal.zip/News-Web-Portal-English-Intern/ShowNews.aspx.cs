﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI.HtmlControls;

public partial class ShowNews : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        con = new SqlConnection(ConfigurationManager.AppSettings["LIS"]);       
        cmd = new SqlCommand();
        con.Open();
        cmd.Connection = con;
        cmd.CommandText = "select video from Data where id=@id and video='Yes' ";
        cmd.Parameters.AddWithValue("@id", Request.QueryString["id"].ToString());
        cmd.Connection = con;
        object obj = cmd.ExecuteScalar();
        if (obj == null)
        {
            btnPlay.Visible = false;
        }
        else
        {
            btnPlay.Visible = true;
        }
        con.Close();

        generatePreview(); // Genearate preview for whatsaap, facebook etc.

    }
    void generatePreview()
    {
        string title = "";
        string details = "";
        string photo = "";

        SqlCommand cmd = new SqlCommand();
        SqlConnection con = new SqlConnection(ConfigurationManager.AppSettings["LIS"]);        
        con.Open();

        cmd.CommandText = "SELECT title, substring(details,1,100), photo FROM Data WHERE id = @id";
        cmd.Parameters.AddWithValue("@id", Request.QueryString["id"].ToString());
        cmd.Connection = con;
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            title = dr.GetString(0);
            details = dr.GetString(1);
            photo = dr.GetString(2);
        }
        con.Close();

        HtmlMeta tag = new HtmlMeta();
        tag.Attributes.Add("property", "og:site_name");
        tag.Content = "www.maharashtratejnews.com/"; // don't HtmlEncode() string. HtmlMeta already escapes characters.
        Page.Header.Controls.Add(tag);

        HtmlMeta tag1 = new HtmlMeta();
        tag1.Attributes.Add("property", "og:url");
        tag1.Content = "http://maharashtratejnews.com//ShowNews.aspx?id" + Request.QueryString["id"].ToString(); // don't HtmlEncode() string. HtmlMeta already escapes characters.
        Page.Header.Controls.Add(tag1);

        HtmlMeta tag2 = new HtmlMeta();
        tag2.Attributes.Add("property", "og:title");
        tag2.Content = title; // don't HtmlEncode() string. HtmlMeta already escapes characters.
        Page.Header.Controls.Add(tag2);

        HtmlMeta tag3 = new HtmlMeta();
        tag3.Attributes.Add("property", "og:type");
        tag3.Content = "blog"; // don't HtmlEncode() string. HtmlMeta already escapes characters.
        Page.Header.Controls.Add(tag3);

        HtmlMeta tag4 = new HtmlMeta();
        tag4.Attributes.Add("property", "og:description");
        tag4.Content = details; // don't HtmlEncode() string. HtmlMeta already escapes characters.                
        Page.Header.Controls.Add(tag4);

        HtmlMeta tag5 = new HtmlMeta();
        tag5.Attributes.Add("property", "og:image");
        tag5.Content = "http://maharashtratejnews.com/News_Photos/" + photo; // don't HtmlEncode() string. HtmlMeta already escapes characters.
        Page.Header.Controls.Add(tag5);


        HtmlMeta tag6 = new HtmlMeta();
        tag6.Attributes.Add("name", "description");
        tag6.Content = details; // don't HtmlEncode() string. HtmlMeta already escapes characters.
        Page.Header.Controls.Add(tag6);
        this.Title = title;

        HtmlMeta tag7 = new HtmlMeta();
        tag7.Attributes.Add("name", "title");
        tag7.Content = title; // don't HtmlEncode() string. HtmlMeta already escapes characters.
        Page.Header.Controls.Add(tag7);
    }
    
    protected void btnPlay_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("ShowVideo.aspx?id=" + Request.QueryString["id"].ToString());
    }
}