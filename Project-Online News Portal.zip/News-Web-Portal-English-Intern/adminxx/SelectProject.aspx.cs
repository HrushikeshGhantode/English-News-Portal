﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class admin_SelectProject : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack == false)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.AppSettings["LIS"]);
            con.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Select cata,title,year,abstract from Project where id=@id";

            cmd.Parameters.AddWithValue("@id", Request.QueryString["id"].ToString());

            cmd.Connection = con;

            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                ddlCata.Text = dr.GetString(0);
                txtProject.Text = dr.GetString(1);
                txtYear.Text = dr.GetString(2);
                txtAbstract.Text = dr.GetString(3); 
            }
        }
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.AppSettings["LIS"]);
        con.Open();

        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "Update Project set cata=@cata,title=@title,year=@year,abstract=@abstract where id=@id";

        cmd.Parameters.AddWithValue("@id",Request.QueryString["id"].ToString());
        cmd.Parameters.AddWithValue("@cata", ddlCata.SelectedItem.ToString());
        cmd.Parameters.AddWithValue("@title", txtProject.Text);
        cmd.Parameters.AddWithValue("@abstract", txtAbstract.Text);
        cmd.Parameters.AddWithValue("@year", txtYear.Text);

        cmd.Connection = con;

            int n = cmd.ExecuteNonQuery();
            
            lblmsg.Text = "Project Record Updated Successfully !";
            txtAbstract.Text = "";
            txtProject.Text = "";
            txtYear.Text = "";
            ddlCata.SelectedIndex = 0;
        
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.AppSettings["LIS"]);
        
        con.Open();

        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "Delete from Project where id=@id";

        cmd.Parameters.AddWithValue("@id", Request.QueryString["id"].ToString());
        
        cmd.Connection = con;

        int n = cmd.ExecuteNonQuery();

        lblmsg.Text = "Project Record Deleted Successfully !";

        txtAbstract.Text = "";
        txtProject.Text = "";
        txtYear.Text = "";
        ddlCata.SelectedIndex = 0;

    }
}