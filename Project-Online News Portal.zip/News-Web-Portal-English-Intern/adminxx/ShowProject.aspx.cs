﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_ShowProject : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void ddlCata_SelectedIndexChanged(object sender, EventArgs e)
    {
        string q = "";

        q="select id,cata,title from Project where cata='"+ddlCata.SelectedItem.Value.ToString()+"'";

        SqlDataGetList.SelectCommand = q;

    }
   
}